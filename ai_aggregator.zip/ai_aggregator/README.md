# AI Чат-агрегатор (Flutter + FastAPI)

Чат с подсветкой кода, который по очереди пробует бесплатные API: **Groq → Cerebras → Gemini**.
При 429 / 5xx / неверном ключе / таймауте автоматически берёт следующего. В каждом ответе
показано, какой провайдер и модель ответили.

Два режима (переключаются в настройках приложения):

1. **Прямой** (рекомендуется) — приложение само ходит к API. Сервер не нужен, всё бесплатно.
2. **Через шлюз** — приложение ходит на ваш FastAPI-backend, а он — к провайдерам.
   Полезно, если ключи хотите хранить на сервере.

```
ai_aggregator/
├── backend/        main.py, requirements.txt, Dockerfile, .env.example
└── flutter_app/    pubspec.yaml, lib/*.dart
```

---

## 1. Бесплатные API и ключи

| Провайдер | Где получить ключ | Модель по умолчанию |
|---|---|---|
| Groq | https://console.groq.com/keys | `llama-3.3-70b-versatile` |
| Cerebras | https://cloud.cerebras.ai (раздел API Keys) | `llama-3.3-70b` |
| Google Gemini | https://aistudio.google.com/apikey | `gemini-2.5-flash` |

Лимиты и список бесплатных моделей меняются. Если провайдер отвечает «model not found» —
откройте его страницу с моделями, выберите актуальное имя и впишите в настройках приложения
(или в переменной `*_MODEL` на сервере). Карта не нужна ни у одного из трёх.

---

## 2. Backend

### Локальный запуск
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

export GROQ_API_KEY=...        # Windows PowerShell: $env:GROQ_API_KEY="..."
export CEREBRAS_API_KEY=...
export GEMINI_API_KEY=...
uvicorn main:app --host 0.0.0.0 --port 8000
```
Проверка:
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/v1/chat -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Привет!"}]}'
```

Ответ: `{"provider":"groq","provider_name":"Groq","model":"...","content":"...","tried":[...]}`.
Эндпоинт `GET /v1/providers` показывает, у каких провайдеров есть ключ и кто на паузе.

Переменные окружения: `GROQ_API_KEY`, `CEREBRAS_API_KEY`, `GEMINI_API_KEY`,
`GATEWAY_TOKEN` (если задан — приложение должно передавать его), `PROVIDER_ORDER`,
`GROQ_MODEL`, `CEREBRAS_MODEL`, `GEMINI_MODEL`.
Ключи можно передавать и заголовками `x-groq-key`, `x-cerebras-key`, `x-gemini-key` —
приложение делает это само, если вы ввели ключи в настройках.

### Docker
```bash
cd backend
docker build -t ai-gateway .
docker run -p 8000:8000 -e PORT=8000 --env-file .env ai-gateway
```

### Бесплатный хостинг

**Render (Web Service, Free):**
1. Залейте папку `backend` в GitHub-репозиторий.
2. https://render.com → New → Web Service → выберите репозиторий → Runtime: **Docker**, Instance: **Free**.
3. В Environment добавьте ключи и `GATEWAY_TOKEN`.
4. Адрес вида `https://ai-gateway-xxxx.onrender.com` вставьте в настройках приложения.
   Free-инстанс засыпает после ~15 минут простоя, первый запрос после сна идёт до минуты.

**Hugging Face Spaces (Docker Space):**
1. https://huggingface.co/new-space → SDK: **Docker** → Blank.
2. Загрузите `main.py`, `requirements.txt`, `Dockerfile`, а в `README.md` Space добавьте шапку:
   ```
   ---
   title: AI Gateway
   sdk: docker
   app_port: 7860
   ---
   ```
3. Settings → Variables and secrets → добавьте ключи как **Secrets**.
4. Адрес: `https://<user>-<space>.hf.space`.

Если шлюз нужен только для себя, установите `GATEWAY_TOKEN`, иначе любой, кто знает URL,
сможет тратить ваши лимиты.

---

## 3. Сборка APK

Нужны: [Flutter SDK](https://docs.flutter.dev/get-started/install) и Android SDK
(ставится вместе с Android Studio). Проверка: `flutter doctor`.

```bash
# 1. Создать каркас проекта (появится папка android/)
flutter create --org com.example --project-name ai_aggregator ai_aggregator
cd ai_aggregator

# 2. Подставить наш код
rm -rf lib test
cp -r /путь/к/ai_aggregator/flutter_app/lib ./lib
cp /путь/к/ai_aggregator/flutter_app/pubspec.yaml ./pubspec.yaml
flutter pub get
```
Если `pub get` ругается на версии — не копируйте pubspec, а выполните в свежем проекте:
```bash
flutter pub add http flutter_secure_storage flutter_markdown markdown flutter_highlight highlight
```

**3. Два правки в Android-конфиге:**

- `android/app/src/main/AndroidManifest.xml` — внутри `<manifest>`, до `<application>`:
  ```xml
  <uses-permission android:name="android.permission.INTERNET"/>
  ```
  Без этого в release-сборке интернета не будет.
- `android/app/build.gradle.kts` (или `build.gradle`) — в `defaultConfig` поставьте
  `minSdk = 23` (для `flutter_secure_storage`; в старом Groovy-формате `minSdkVersion 23`).

Если шлюз у вас по `http://` (локальная сеть), добавьте в тег `<application ...>`
атрибут `android:usesCleartextTraffic="true"`. Для хостингов выше (https) не нужно.

**4. Сборка:**
```bash
flutter build apk --release                  # один универсальный APK
flutter build apk --release --split-per-abi  # меньше размер, по одному APK на архитектуру
```
Результат: `build/app/outputs/flutter-apk/app-release.apk`
(для `--split-per-abi` обычно ставят `app-arm64-v8a-release.apk`).

**5. Установка:** перекиньте APK на телефон и откройте (разрешите установку из неизвестных
источников) или `adb install build/app/outputs/flutter-apk/app-release.apk`.
Шаблон Flutter подписывает release отладочным ключом — для личного использования этого
достаточно. Для публикации в Google Play нужна своя подпись:
https://docs.flutter.dev/deployment/android

**Запуск для разработки:** `flutter run` (телефон по USB с включённой отладкой или эмулятор).
С эмулятора локальный backend доступен по `http://10.0.2.2:8000`.

---

## 4. Как работает переключение

- Провайдеры перебираются в порядке из настроек (стрелки ↑↓, переключатель — отключить).
- `429` → пауза провайдера на время `Retry-After` (или 60 с), следующий в очереди.
- `5xx` / сеть / таймаут → пауза 20–30 с, следующий.
- `401/403` → ключ не принят, пауза 10 минут, следующий.
- Пустой ответ или другая ошибка → следующий.
- Если не ответил никто — в чате красное сообщение со списком причин по каждому провайдеру.
- В диалог уходят последние 20 сообщений; при переключении контекст сохраняется.

Ограничения версии: ответы приходят целиком (без потокового вывода), история чата не
сохраняется между запусками. Оба пункта легко добавить поверх этого кода.
