"""
AI Gateway — шлюз к бесплатным LLM-API с автоматическим переключением.

Порядок провайдеров по умолчанию: Groq -> Cerebras -> Gemini.
Если провайдер вернул 429 / 5xx / 401 / таймаут — берём следующего.
Ключи берутся из переменных окружения или из заголовков запроса
(X-Groq-Key, X-Cerebras-Key, X-Gemini-Key) — заголовок приоритетнее.
"""
import logging
import os
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("gateway")


@dataclass(frozen=True)
class Provider:
    id: str
    name: str
    url: str
    model: str
    env_key: str


PROVIDERS: Dict[str, Provider] = {
    "groq": Provider(
        "groq", "Groq",
        "https://api.groq.com/openai/v1/chat/completions",
        os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        "GROQ_API_KEY",
    ),
    "cerebras": Provider(
        "cerebras", "Cerebras",
        "https://api.cerebras.ai/v1/chat/completions",
        os.getenv("CEREBRAS_MODEL", "llama-3.3-70b"),
        "CEREBRAS_API_KEY",
    ),
    "gemini": Provider(
        "gemini", "Google Gemini",
        # OpenAI-совместимый эндпоинт Gemini
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        "GEMINI_API_KEY",
    ),
}

ORDER: List[str] = [
    x.strip()
    for x in os.getenv("PROVIDER_ORDER", "groq,cerebras,gemini").split(",")
    if x.strip() in PROVIDERS
]

GATEWAY_TOKEN = os.getenv("GATEWAY_TOKEN", "")

# (provider_id:key_suffix) -> unix time, до которого провайдер на паузе
cooldown_until: Dict[str, float] = {}


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: List[Message]
    temperature: float = 0.7
    max_tokens: int = 2048
    preferred: Optional[str] = None  # id провайдера, который пробовать первым


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.client = httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0))
    yield
    await app.state.client.aclose()


app = FastAPI(title="AI Gateway", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def check_auth(request: Request) -> None:
    if not GATEWAY_TOKEN:
        return
    if request.headers.get("authorization", "") != f"Bearer {GATEWAY_TOKEN}":
        raise HTTPException(status_code=401, detail="Неверный токен шлюза")


def get_key(request: Request, p: Provider) -> str:
    return (request.headers.get(f"x-{p.id}-key") or os.getenv(p.env_key, "")).strip()


def retry_after_seconds(resp: httpx.Response, default: int) -> int:
    try:
        return max(1, min(int(float(resp.headers.get("retry-after", default))), 3600))
    except (TypeError, ValueError):
        return default


@app.get("/")
@app.get("/health")
async def health():
    return {"status": "ok", "order": ORDER}


@app.get("/v1/providers")
async def providers_status(request: Request):
    check_auth(request)
    now = time.time()
    out = []
    for pid in ORDER:
        p = PROVIDERS[pid]
        key = get_key(request, p)
        left = max(0, int(cooldown_until.get(f"{pid}:{key[-6:]}", 0) - now))
        out.append({
            "id": pid, "name": p.name, "model": p.model,
            "has_key": bool(key), "cooldown_seconds": left,
        })
    return out


@app.post("/v1/chat")
async def chat(req: ChatRequest, request: Request):
    check_auth(request)
    client: httpx.AsyncClient = request.app.state.client

    order = ORDER[:]
    if req.preferred in order:
        order.remove(req.preferred)
        order.insert(0, req.preferred)

    tried = []
    for pid in order:
        p = PROVIDERS[pid]
        key = get_key(request, p)
        if not key:
            tried.append({"provider": pid, "status": "no_key"})
            continue

        ck = f"{pid}:{key[-6:]}"
        if cooldown_until.get(ck, 0) > time.time():
            tried.append({"provider": pid, "status": "cooldown"})
            continue

        payload = {
            "model": p.model,
            "messages": [m.model_dump() for m in req.messages],
            "temperature": req.temperature,
            "max_tokens": req.max_tokens,
        }
        try:
            r = await client.post(
                p.url,
                json=payload,
                headers={"Authorization": f"Bearer {key}"},
            )
        except httpx.HTTPError as e:
            log.warning("%s: сетевая ошибка %r", pid, e)
            cooldown_until[ck] = time.time() + 20
            tried.append({"provider": pid, "status": "network_error", "detail": repr(e)[:200]})
            continue

        if r.status_code == 200:
            try:
                content = r.json()["choices"][0]["message"]["content"]
            except (KeyError, IndexError, ValueError, TypeError):
                content = None
            if content and str(content).strip():
                log.info("ответил %s (%s)", pid, p.model)
                return {
                    "provider": pid,
                    "provider_name": p.name,
                    "model": p.model,
                    "content": content,
                    "tried": tried,
                }
            tried.append({"provider": pid, "status": "empty_response"})
            continue

        if r.status_code == 429:
            cooldown_until[ck] = time.time() + retry_after_seconds(r, 60)
            status = "rate_limited"
        elif r.status_code >= 500:
            cooldown_until[ck] = time.time() + 30
            status = "server_error"
        elif r.status_code in (401, 403):
            cooldown_until[ck] = time.time() + 600
            status = "bad_key"
        else:
            status = f"http_{r.status_code}"

        log.warning("%s: %s (%s) %s", pid, status, r.status_code, r.text[:200])
        tried.append({
            "provider": pid, "status": status,
            "http": r.status_code, "detail": r.text[:200],
        })

    raise HTTPException(
        status_code=503,
        detail={"message": "Все провайдеры недоступны", "tried": tried},
    )
