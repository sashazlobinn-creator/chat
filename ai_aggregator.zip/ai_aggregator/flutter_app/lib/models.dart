class ChatMessage {
  final String role; // 'user' | 'assistant'
  final String content;
  final String? providerName;
  final String? model;
  final bool isError;

  ChatMessage({
    required this.role,
    required this.content,
    this.providerName,
    this.model,
    this.isError = false,
  });
}

class AiResult {
  final String content;
  final String providerId;
  final String providerName;
  final String model;

  AiResult({
    required this.content,
    required this.providerId,
    required this.providerName,
    required this.model,
  });
}

class AllProvidersFailed implements Exception {
  final List<String> log;
  AllProvidersFailed(this.log);

  @override
  String toString() => 'Все провайдеры недоступны:\n${log.join('\n')}';
}
