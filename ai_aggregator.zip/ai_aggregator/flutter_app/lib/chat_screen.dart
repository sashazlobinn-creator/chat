import 'package:flutter/material.dart';
import 'chat_service.dart';
import 'message_bubble.dart';
import 'models.dart';
import 'settings.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _service = ChatService();
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatMessage> _messages = [];

  AppSettings? _settings;
  bool _loading = false;
  String _status = '';
  String? _activeProvider;

  @override
  void initState() {
    super.initState();
    SettingsStore.load().then((s) {
      if (mounted) setState(() => _settings = s);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _openSettings() async {
    final s = _settings ?? await SettingsStore.load();
    if (!mounted) return;
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => SettingsScreen(settings: s)),
    );
    if (saved == true) {
      final fresh = await SettingsStore.load();
      if (mounted) setState(() => _settings = fresh);
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    final settings = _settings;
    if (text.isEmpty || _loading || settings == null) return;

    _controller.clear();
    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text));
      _loading = true;
      _status = 'Подключение…';
    });
    _scrollToEnd();

    try {
      final res = await _service.send(
        settings,
        _messages,
        onStatus: (s) {
          if (mounted) setState(() => _status = s);
        },
      );
      if (!mounted) return;
      setState(() {
        _activeProvider = '${res.providerName} · ${res.model}';
        _messages.add(ChatMessage(
          role: 'assistant',
          content: res.content,
          providerName: res.providerName,
          model: res.model,
        ));
      });
    } on AllProvidersFailed catch (e) {
      if (!mounted) return;
      final hint = settings.hasAnyKey || settings.useGateway
          ? ''
          : '\n\nДобавьте API-ключи в настройках (⚙).';
      setState(() => _messages.add(
          ChatMessage(role: 'assistant', content: '$e$hint', isError: true)));
    } catch (e) {
      if (!mounted) return;
      setState(() => _messages.add(
          ChatMessage(role: 'assistant', content: 'Ошибка: $e', isError: true)));
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToEnd();
    }
  }

  void _clear() => setState(() {
        _messages.clear();
        _activeProvider = null;
      });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final needsSetup =
        _settings != null && !_settings!.hasAnyKey && !_settings!.useGateway;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('AI Чат', style: TextStyle(fontSize: 18)),
            Text(
              _loading
                  ? _status
                  : (_activeProvider != null
                      ? 'Отвечает: $_activeProvider'
                      : 'Автопереключение провайдеров'),
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Очистить чат',
            icon: const Icon(Icons.delete_outline),
            onPressed: _messages.isEmpty || _loading ? null : _clear,
          ),
          IconButton(
            tooltip: 'Настройки',
            icon: const Icon(Icons.settings_outlined),
            onPressed: _openSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome,
                              size: 48, color: cs.primary),
                          const SizedBox(height: 12),
                          Text(
                            needsSetup
                                ? 'Добавьте бесплатные API-ключи, чтобы начать'
                                : 'Задайте вопрос',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          if (needsSetup) ...[
                            const SizedBox(height: 12),
                            FilledButton.icon(
                              onPressed: _openSettings,
                              icon: const Icon(Icons.key),
                              label: const Text('Открыть настройки'),
                            ),
                          ],
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _messages.length,
                    itemBuilder: (_, i) => MessageBubble(msg: _messages[i]),
                  ),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      minLines: 1,
                      maxLines: 6,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        hintText: 'Сообщение…',
                        filled: true,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _loading ? null : _send,
                    icon: const Icon(Icons.send),
                    tooltip: 'Отправить',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
