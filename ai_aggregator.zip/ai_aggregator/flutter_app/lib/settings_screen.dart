import 'package:flutter/material.dart';
import 'settings.dart';

class SettingsScreen extends StatefulWidget {
  final AppSettings settings;
  const SettingsScreen({super.key, required this.settings});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late List<ProviderSettings> _providers;
  late bool _useGateway;
  late final TextEditingController _gwUrl;
  late final TextEditingController _gwToken;
  final Map<String, TextEditingController> _keyC = {};
  final Map<String, TextEditingController> _modelC = {};
  final Set<String> _visible = {};

  @override
  void initState() {
    super.initState();
    final s = widget.settings;
    _providers = s.providers.map((p) => p.clone()).toList();
    _useGateway = s.useGateway;
    _gwUrl = TextEditingController(text: s.gatewayUrl);
    _gwToken = TextEditingController(text: s.gatewayToken);
    for (final p in _providers) {
      _keyC[p.id] = TextEditingController(text: p.key);
      _modelC[p.id] = TextEditingController(text: p.model);
    }
  }

  @override
  void dispose() {
    _gwUrl.dispose();
    _gwToken.dispose();
    for (final c in [..._keyC.values, ..._modelC.values]) {
      c.dispose();
    }
    super.dispose();
  }

  void _move(int i, int delta) {
    final j = i + delta;
    if (j < 0 || j >= _providers.length) return;
    setState(() {
      final p = _providers.removeAt(i);
      _providers.insert(j, p);
    });
  }

  Future<void> _save() async {
    for (final p in _providers) {
      p.key = _keyC[p.id]!.text.trim();
      final m = _modelC[p.id]!.text.trim();
      if (m.isNotEmpty) p.model = m;
    }
    final s = AppSettings(
      providers: _providers,
      useGateway: _useGateway,
      gatewayUrl: _gwUrl.text.trim(),
      gatewayToken: _gwToken.text.trim(),
    );
    await SettingsStore.save(s);
    if (mounted) Navigator.of(context).pop(true);
  }

  Widget _providerCard(int i) {
    final p = _providers[i];
    final visible = _visible.contains(p.id);
    return Card(
      margin: const EdgeInsets.only(top: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(radius: 12, child: Text('${i + 1}')),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(p.name,
                      style: Theme.of(context).textTheme.titleMedium),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.arrow_upward),
                  onPressed: i == 0 ? null : () => _move(i, -1),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.arrow_downward),
                  onPressed:
                      i == _providers.length - 1 ? null : () => _move(i, 1),
                ),
                Switch(
                  value: p.enabled,
                  onChanged: (v) => setState(() => p.enabled = v),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _keyC[p.id],
              obscureText: !visible,
              autocorrect: false,
              enableSuggestions: false,
              decoration: InputDecoration(
                labelText: 'API-ключ',
                border: const OutlineInputBorder(),
                isDense: true,
                suffixIcon: IconButton(
                  icon: Icon(visible ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() {
                    visible ? _visible.remove(p.id) : _visible.add(p.id);
                  }),
                ),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _modelC[p.id],
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Модель',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
            const SizedBox(height: 8),
            SelectableText(
              'Получить ключ: ${p.signup}',
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Настройки'),
        actions: [
          TextButton(onPressed: _save, child: const Text('Сохранить')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Работать через свой шлюз'),
            subtitle: const Text(
                'Выключено — приложение обращается к API напрямую'),
            value: _useGateway,
            onChanged: (v) => setState(() => _useGateway = v),
          ),
          if (_useGateway) ...[
            const SizedBox(height: 8),
            TextField(
              controller: _gwUrl,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Адрес шлюза (https://…)',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _gwToken,
              obscureText: true,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Токен шлюза (если задан)',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
          ],
          const Divider(height: 32),
          Text(
            'Провайдеры. Порядок = приоритет: при лимите или ошибке '
            'приложение берёт следующего по списку.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          for (var i = 0; i < _providers.length; i++) _providerCard(i),
        ],
      ),
    );
  }
}
