import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models.dart';
import 'settings.dart';

const _systemPrompt = 'Ты — полезный ассистент. Отвечай на языке пользователя. '
    'Код всегда оформляй в блоках Markdown с указанием языка.';

class ChatService {
  final Map<String, DateTime> _cooldown = {};
  static const _maxHistory = 20;
  static const _timeout = Duration(seconds: 60);

  Future<AiResult> send(
    AppSettings s,
    List<ChatMessage> history, {
    void Function(String status)? onStatus,
  }) {
    return s.useGateway
        ? _viaGateway(s, history, onStatus)
        : _direct(s, history, onStatus);
  }

  List<Map<String, String>> _payload(List<ChatMessage> history) {
    final clean = history.where((m) => !m.isError).toList();
    final tail = clean.length > _maxHistory
        ? clean.sublist(clean.length - _maxHistory)
        : clean;
    return <Map<String, String>>[
      {'role': 'system', 'content': _systemPrompt},
      for (final m in tail) {'role': m.role, 'content': m.content},
    ];
  }

  // ---------- Прямой режим: приложение -> API провайдера ----------
  Future<AiResult> _direct(
    AppSettings s,
    List<ChatMessage> history,
    void Function(String)? onStatus,
  ) async {
    final log = <String>[];
    final messages = _payload(history);

    for (final p in s.providers.where((p) => p.enabled)) {
      if (p.key.trim().isEmpty) {
        log.add('${p.name}: нет ключа');
        continue;
      }
      final until = _cooldown[p.id];
      if (until != null && until.isAfter(DateTime.now())) {
        final sec = until.difference(DateTime.now()).inSeconds;
        log.add('${p.name}: пауза после лимита ещё ~$sec с');
        continue;
      }

      onStatus?.call('Запрос к ${p.name}…');
      try {
        final r = await http
            .post(
              Uri.parse(p.url),
              headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ${p.key.trim()}',
              },
              body: jsonEncode({
                'model': p.model,
                'messages': messages,
                'temperature': 0.7,
                'max_tokens': 2048,
              }),
            )
            .timeout(_timeout);

        final body = utf8.decode(r.bodyBytes);

        if (r.statusCode == 200) {
          final data = jsonDecode(body) as Map<String, dynamic>;
          final content = data['choices']?[0]?['message']?['content'];
          if (content is String && content.trim().isNotEmpty) {
            return AiResult(
              content: content,
              providerId: p.id,
              providerName: p.name,
              model: p.model,
            );
          }
          log.add('${p.name}: пустой ответ');
          onStatus?.call('${p.name}: пустой ответ, переключаюсь…');
          continue;
        }

        if (r.statusCode == 429) {
          final ra = int.tryParse(r.headers['retry-after'] ?? '') ?? 60;
          _cooldown[p.id] =
              DateTime.now().add(Duration(seconds: ra.clamp(1, 3600)));
          log.add('${p.name}: лимит запросов (429)');
          onStatus?.call('${p.name}: лимит исчерпан, переключаюсь…');
        } else if (r.statusCode >= 500) {
          _cooldown[p.id] = DateTime.now().add(const Duration(seconds: 30));
          log.add('${p.name}: ошибка сервера (${r.statusCode})');
          onStatus?.call('${p.name}: сбой сервера, переключаюсь…');
        } else if (r.statusCode == 401 || r.statusCode == 403) {
          _cooldown[p.id] = DateTime.now().add(const Duration(minutes: 10));
          log.add('${p.name}: неверный ключ (${r.statusCode})');
          onStatus?.call('${p.name}: ключ не принят, переключаюсь…');
        } else {
          final short = body.length > 160 ? body.substring(0, 160) : body;
          log.add('${p.name}: HTTP ${r.statusCode} $short');
          onStatus?.call('${p.name}: ошибка ${r.statusCode}, переключаюсь…');
        }
      } catch (e) {
        _cooldown[p.id] = DateTime.now().add(const Duration(seconds: 20));
        log.add('${p.name}: ${e is TimeoutException ? 'таймаут' : 'сетевая ошибка'}');
        onStatus?.call('${p.name}: нет связи, переключаюсь…');
      }
    }
    throw AllProvidersFailed(log);
  }

  // ---------- Режим шлюза: приложение -> свой backend ----------
  Future<AiResult> _viaGateway(
    AppSettings s,
    List<ChatMessage> history,
    void Function(String)? onStatus,
  ) async {
    final base = s.gatewayUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) {
      throw AllProvidersFailed(['Не указан адрес шлюза в настройках']);
    }
    onStatus?.call('Запрос к шлюзу…');

    final headers = <String, String>{
      'Content-Type': 'application/json; charset=utf-8',
    };
    if (s.gatewayToken.trim().isNotEmpty) {
      headers['Authorization'] = 'Bearer ${s.gatewayToken.trim()}';
    }
    // Ключи из приложения передаём шлюзу (если на сервере ключей нет)
    for (final p in s.providers) {
      if (p.key.trim().isNotEmpty) headers['x-${p.id}-key'] = p.key.trim();
    }

    try {
      final r = await http
          .post(
            Uri.parse('$base/v1/chat'),
            headers: headers,
            body: jsonEncode({'messages': _payload(history)}),
          )
          .timeout(const Duration(seconds: 120));
      final data = jsonDecode(utf8.decode(r.bodyBytes));

      if (r.statusCode == 200) {
        return AiResult(
          content: data['content'] as String,
          providerId: data['provider'] as String,
          providerName: data['provider_name'] as String,
          model: data['model'] as String,
        );
      }

      final log = <String>['Шлюз: HTTP ${r.statusCode}'];
      final detail = data is Map ? data['detail'] : null;
      if (detail is Map) {
        for (final t in (detail['tried'] as List? ?? const [])) {
          log.add('${t['provider']}: ${t['status']}');
        }
      } else if (detail is String) {
        log.add(detail);
      }
      throw AllProvidersFailed(log);
    } on AllProvidersFailed {
      rethrow;
    } catch (e) {
      throw AllProvidersFailed([
        'Шлюз недоступен: ${e is TimeoutException ? 'таймаут' : e}'
      ]);
    }
  }
}
