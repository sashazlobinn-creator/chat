import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ProviderSettings {
  final String id;
  final String name;
  final String url;
  final String signup;
  String model;
  String key;
  bool enabled;

  ProviderSettings({
    required this.id,
    required this.name,
    required this.url,
    required this.signup,
    required this.model,
    this.key = '',
    this.enabled = true,
  });

  ProviderSettings clone() => ProviderSettings(
        id: id,
        name: name,
        url: url,
        signup: signup,
        model: model,
        key: key,
        enabled: enabled,
      );

  Map<String, dynamic> toJson() =>
      {'id': id, 'model': model, 'key': key, 'enabled': enabled};
}

class AppSettings {
  List<ProviderSettings> providers;
  bool useGateway;
  String gatewayUrl;
  String gatewayToken;

  AppSettings({
    required this.providers,
    this.useGateway = false,
    this.gatewayUrl = '',
    this.gatewayToken = '',
  });

  static AppSettings defaults() => AppSettings(providers: [
        ProviderSettings(
          id: 'groq',
          name: 'Groq',
          url: 'https://api.groq.com/openai/v1/chat/completions',
          signup: 'https://console.groq.com/keys',
          model: 'llama-3.3-70b-versatile',
        ),
        ProviderSettings(
          id: 'cerebras',
          name: 'Cerebras',
          url: 'https://api.cerebras.ai/v1/chat/completions',
          signup: 'https://cloud.cerebras.ai',
          model: 'llama-3.3-70b',
        ),
        ProviderSettings(
          id: 'gemini',
          name: 'Google Gemini',
          url:
              'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
          signup: 'https://aistudio.google.com/apikey',
          model: 'gemini-2.5-flash',
        ),
      ]);

  bool get hasAnyKey => providers.any((p) => p.key.trim().isNotEmpty);

  Map<String, dynamic> toJson() => {
        'providers': providers.map((p) => p.toJson()).toList(),
        'useGateway': useGateway,
        'gatewayUrl': gatewayUrl,
        'gatewayToken': gatewayToken,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) {
    final d = AppSettings.defaults();
    final list = <ProviderSettings>[];
    for (final raw in (j['providers'] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(raw as Map);
      final def = d.providers.where((p) => p.id == m['id']).firstOrNull;
      if (def == null) continue;
      def.model = (m['model'] as String?)?.trim().isNotEmpty == true
          ? m['model'] as String
          : def.model;
      def.key = (m['key'] as String?) ?? '';
      def.enabled = (m['enabled'] as bool?) ?? true;
      list.add(def);
    }
    for (final def in d.providers) {
      if (!list.any((p) => p.id == def.id)) list.add(def);
    }
    return AppSettings(
      providers: list,
      useGateway: (j['useGateway'] as bool?) ?? false,
      gatewayUrl: (j['gatewayUrl'] as String?) ?? '',
      gatewayToken: (j['gatewayToken'] as String?) ?? '',
    );
  }
}

class SettingsStore {
  static const _storage = FlutterSecureStorage();
  static const _k = 'app_settings_v1';

  static Future<AppSettings> load() async {
    try {
      final raw = await _storage.read(key: _k);
      if (raw == null) return AppSettings.defaults();
      return AppSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return AppSettings.defaults();
    }
  }

  static Future<void> save(AppSettings s) =>
      _storage.write(key: _k, value: jsonEncode(s.toJson()));
}
