import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:highlight/highlight.dart' show highlight;
import 'package:markdown/markdown.dart' as md;
import 'models.dart';

void _copy(BuildContext context, String text) {
  Clipboard.setData(ClipboardData(text: text));
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(const SnackBar(
      content: Text('Скопировано'),
      duration: Duration(seconds: 1),
    ));
}

class MessageBubble extends StatelessWidget {
  final ChatMessage msg;
  const MessageBubble({super.key, required this.msg});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isUser = msg.role == 'user';
    final maxW = MediaQuery.of(context).size.width * (isUser ? 0.85 : 0.94);

    Widget content;
    Color bg;
    if (msg.isError) {
      bg = cs.errorContainer;
      content = SelectableText(
        msg.content,
        style: TextStyle(color: cs.onErrorContainer),
      );
    } else if (isUser) {
      bg = cs.primaryContainer;
      content = SelectableText(
        msg.content,
        style: TextStyle(color: cs.onPrimaryContainer, fontSize: 15),
      );
    } else {
      bg = cs.surfaceContainerHighest;
      content = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MarkdownBody(
            data: msg.content,
            selectable: true,
            builders: {'code': CodeBlockBuilder()},
            styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
              codeblockPadding: EdgeInsets.zero,
              codeblockDecoration: const BoxDecoration(),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (msg.providerName != null)
                Flexible(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: cs.secondaryContainer,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${msg.providerName} · ${msg.model ?? ''}',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: cs.onSecondaryContainer,
                      ),
                    ),
                  ),
                ),
              IconButton(
                visualDensity: VisualDensity.compact,
                iconSize: 18,
                tooltip: 'Копировать ответ',
                icon: const Icon(Icons.copy_all_outlined),
                onPressed: () => _copy(context, msg.content),
              ),
            ],
          ),
        ],
      );
    }

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxW),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(16),
          ),
          child: content,
        ),
      ),
    );
  }
}

/// Заменяет многострочные блоки кода на виджет с подсветкой.
class CodeBlockBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfterWithContext(
    BuildContext context,
    md.Element element,
    TextStyle? preferredStyle,
    TextStyle? parentStyle,
  ) {
    final text = element.textContent;
    // Однострочный inline-код оставляем стандартному рендеру
    if (!text.contains('\n')) return null;

    var lang = '';
    final cls = element.attributes['class'];
    if (cls != null && cls.startsWith('language-')) {
      lang = cls.substring('language-'.length);
    }
    return CodeBlock(code: text.trimRight(), language: lang);
  }
}

class CodeBlock extends StatelessWidget {
  final String code;
  final String language;
  const CodeBlock({super.key, required this.code, required this.language});

  bool get _canHighlight {
    if (language.isEmpty) return false;
    try {
      highlight.parse(code, language: language);
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    const mono = TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.4);

    final body = _canHighlight
        ? HighlightView(
            code,
            language: language,
            theme: atomOneDarkTheme,
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            textStyle: mono,
          )
        : Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: Text(
              code,
              style: mono.copyWith(color: const Color(0xFFABB2BF)),
            ),
          );

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF282C34),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Row(
              children: [
                Text(
                  language.isEmpty ? 'code' : language,
                  style: const TextStyle(color: Color(0xFF9DA5B4), fontSize: 12),
                ),
                const Spacer(),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  color: const Color(0xFF9DA5B4),
                  tooltip: 'Копировать код',
                  icon: const Icon(Icons.copy),
                  onPressed: () => _copy(context, code),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: body,
          ),
        ],
      ),
    );
  }
}
